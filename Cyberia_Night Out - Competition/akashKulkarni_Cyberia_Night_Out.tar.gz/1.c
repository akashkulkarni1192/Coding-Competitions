#include<stdio.h>
void main(){
	if(printf("Akash Kulkarni\n")){

	}
}